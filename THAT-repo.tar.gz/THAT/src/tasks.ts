export type Task = {
  id: string;
  prompt: string;
  sequence: string[];            // visible items; the missing one is appended as the drop zone
  options: string[];             // draggable blocks
  answer: string;
};

export const TASKS: Task[] = [
  { id: 't1', prompt: 'Complete the pattern', sequence: ['■', '●', '■', '●'], options: ['■', '▲'], answer: '■' },
  { id: 't2', prompt: 'Complete the pattern', sequence: ['▲', '▲', '■', '▲', '▲'], options: ['■', '●'], answer: '■' },
  { id: 't3', prompt: 'Complete the pattern', sequence: ['1', '2', '3', '4'], options: ['5', '9'], answer: '5' },
  { id: 't4', prompt: 'Complete the pattern', sequence: ['A', 'B', 'A', 'B'], options: ['B', 'A'], answer: 'A' },
];
