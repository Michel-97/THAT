import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';

// Point this at your PHP host. Local-first: the app works fully offline.
const API = 'http://localhost:8000/api/v1/events';
const K = { user: 'user', days: 'days', queue: 'queue' };

export const localDate = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export async function getUserId(): Promise<string> {
  let id = await AsyncStorage.getItem(K.user);
  if (!id) { id = Crypto.randomUUID(); await AsyncStorage.setItem(K.user, id); } // anonymous: no sign-up
  return id;
}

export async function getDays(): Promise<string[]> {
  return JSON.parse((await AsyncStorage.getItem(K.days)) ?? '[]');
}

export async function markDayLearned(): Promise<number> {
  const days = new Set(await getDays());
  days.add(localDate());                      // total days only ever goes up
  const arr = [...days];
  await AsyncStorage.setItem(K.days, JSON.stringify(arr));
  return arr.length;
}

type Ev = { key: string; user_id: string; type: string; task_id: string; state: object; local_date: string; payload: object };

// Save locally first, then try the network. Failed sends stay queued.
export async function saveEvent(type: string, task_id: string, state: object, payload: object = {}) {
  const ev: Ev = { key: Crypto.randomUUID(), user_id: await getUserId(), type, task_id, state, payload, local_date: localDate() };
  const q: Ev[] = JSON.parse((await AsyncStorage.getItem(K.queue)) ?? '[]');
  q.push(ev);
  await AsyncStorage.setItem(K.queue, JSON.stringify(q));
  flush();
}

let flushing = false;
export async function flush() {
  if (flushing) return;
  flushing = true;
  try {
    let q: Ev[] = JSON.parse((await AsyncStorage.getItem(K.queue)) ?? '[]');
    while (q.length) {
      const r = await fetch(API, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(q[0]) });
      if (!r.ok) break;
      q = q.slice(1);
      await AsyncStorage.setItem(K.queue, JSON.stringify(q));
    }
  } catch { /* offline: retry on next save */ }
  flushing = false;
}
