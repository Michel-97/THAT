import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, AccessibilityInfo, SafeAreaView } from 'react-native';
import { GestureHandlerRootView, Gesture, GestureDetector, Directions } from 'react-native-gesture-handler';
import Animated, { useSharedValue, useAnimatedStyle, withSequence, withTiming } from 'react-native-reanimated';
import { Header } from './components/Header';
import { DragBlock, Rect } from './components/DragBlock';
import { TASKS } from './tasks';
import { theme } from './theme';
import { getDays, markDayLearned, saveEvent, flush } from './storage';

export default function App() {
  const [i, setI] = useState(0);
  const [solved, setSolved] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [days, setDays] = useState(0);
  const [reduced, setReduced] = useState(false);
  const zone = useSharedValue<Rect>({ x: 0, y: 0, w: 0, h: 0 });
  const zoneRef = useRef<View>(null);
  const pulse = useSharedValue(1);
  const task = TASKS[i % TASKS.length];

  useEffect(() => {
    getDays().then(d => setDays(d.length));
    AccessibilityInfo.isReduceMotionEnabled().then(setReduced);
    flush();
  }, []);

  const measureZone = () =>
    zoneRef.current?.measureInWindow((x, y, w, h) => { zone.value = { x, y, w, h }; });

  const solve = async () => {
    setSolved(true);
    saveEvent('task_complete', task.id, { solved: true });
    setDays(await markDayLearned());
  };
  const miss = () => {
    if (!reduced) pulse.value = withSequence(withTiming(1.05, { duration: 150 }), withTiming(1, { duration: 200 }));
    saveEvent('attempt', task.id, { solved: false });
  };
  const next = () => { setSolved(false); setSelected(null); setI(n => n + 1); };

  const swipeUp = Gesture.Fling().direction(Directions.UP).enabled(solved).onEnd((_e, ok) => { if (ok) next(); }).runOnJS(true);
  const zoneStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  const onZoneTap = () => {
    if (!selected) return;
    selected === task.answer ? solve() : (setSelected(null), miss());
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <GestureDetector gesture={swipeUp}>
        <SafeAreaView style={s.screen}>
          <Header progress={((i % TASKS.length) + (solved ? 1 : 0)) / TASKS.length} days={days} />

          <View style={s.center}>
            <Text style={s.prompt}>{task.prompt}</Text>

            <View style={s.row}>
              {task.sequence.map((c, k) => <View key={k} style={s.fixed}><Text style={s.fixedText}>{c}</Text></View>)}
              <Pressable onPress={onZoneTap} accessibilityRole="button" accessibilityLabel="Drop zone">
                <Animated.View ref={zoneRef as any} onLayout={measureZone} style={[s.zone, solved && s.zoneDone, zoneStyle]}>
                  <Text style={[s.fixedText, !solved && { color: theme.ink }]}>{solved ? task.answer : '?'}</Text>
                </Animated.View>
              </Pressable>
            </View>

            {/* Proximity: blocks sit right under the zone */}
            <View style={s.options}>
              {!solved && task.options.map(o => (
                <DragBlock key={task.id + o} label={o} isCorrect={o === task.answer} zone={zone}
                  selected={selected === o} reducedMotion={reduced}
                  onSolved={solve} onMiss={miss} onSelect={() => setSelected(o)} />
              ))}
              {solved && <Text style={s.done}>Nice. Got it.</Text>}
            </View>
          </View>

          <Pressable style={s.footer} disabled={!solved} onPress={next} accessibilityLabel="Next task">
            {solved && <Text style={s.swipe}>︿{'\n'}Swipe up for next task</Text>}
          </Pressable>
        </SafeAreaView>
      </GestureDetector>
    </GestureHandlerRootView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: theme.bg },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 28 },
  prompt: { fontSize: 26, fontWeight: '700', color: theme.ink },
  row: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  fixed: { width: 52, height: 52, borderRadius: 10, backgroundColor: theme.block, alignItems: 'center', justifyContent: 'center' },
  fixedText: { color: theme.blockText, fontSize: 26 },
  // Closure: dashed border, transparent fill
  zone: { width: 64, height: 64, borderRadius: 12, borderWidth: 3, borderStyle: 'dashed', borderColor: theme.zoneBorder, backgroundColor: 'transparent', alignItems: 'center', justifyContent: 'center' },
  zoneDone: { borderStyle: 'solid', backgroundColor: theme.block },
  options: { flexDirection: 'row', gap: 24, minHeight: 90, alignItems: 'center' },
  done: { fontSize: 20, color: theme.inkSoft },
  footer: { height: 90, alignItems: 'center', justifyContent: 'center' },
  swipe: { textAlign: 'center', color: theme.inkSoft, fontSize: 16 },
});
