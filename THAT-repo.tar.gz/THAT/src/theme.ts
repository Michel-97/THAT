// Muted palette, one accent. No red anywhere: a wrong answer is never an "error".
export const theme = {
  bg: '#E9ECF3',
  ink: '#1F2A44',
  inkSoft: '#5B6682',
  block: '#1F2A44',
  blockText: '#F4F6FB',
  accent: '#3F6FD8',
  zoneBorder: '#3F6FD8', // >= 3:1 against bg (WCAG 1.4.11)
  track: '#CBD2E1',
  radius: 14,
};
