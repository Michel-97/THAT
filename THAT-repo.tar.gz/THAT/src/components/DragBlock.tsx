import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withTiming, runOnJS, SharedValue } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { theme } from '../theme';

export type Rect = { x: number; y: number; w: number; h: number };

export function DragBlock({ label, isCorrect, zone, selected, reducedMotion, onSolved, onMiss, onSelect }: {
  label: string; isCorrect: boolean; zone: SharedValue<Rect>; selected: boolean; reducedMotion: boolean;
  onSolved: () => void; onMiss: () => void; onSelect: () => void;
}) {
  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const spring = reducedMotion ? { duration: 1 } : undefined;

  const pan = Gesture.Pan()
    .onBegin(() => { scale.value = withSpring(1.1); runOnJS(Haptics.selectionAsync)(); })
    .onUpdate(e => { x.value = e.translationX; y.value = e.translationY; })
    .onEnd(e => {
      scale.value = withSpring(1);
      const z = zone.value;
      const hit = e.absoluteX > z.x && e.absoluteX < z.x + z.w && e.absoluteY > z.y && e.absoluteY < z.y + z.h;
      if (hit && isCorrect) {
        opacity.value = withTiming(0, { duration: 120 });
        runOnJS(Haptics.notificationAsync)(Haptics.NotificationFeedbackType.Success);
        runOnJS(onSolved)();
      } else {
        // Gentle spring-back. No red, no buzzer, no penalty.
        x.value = withSpring(0, { damping: 12 });
        y.value = withSpring(0, { damping: 12 });
        if (hit) { runOnJS(Haptics.selectionAsync)(); runOnJS(onMiss)(); }
      }
    });

  // Fallback for non-drag users (WCAG 2.2 SC 2.5.7): tap a block, then tap the zone.
  const tap = Gesture.Tap().onEnd(() => runOnJS(onSelect)());

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateX: x.value }, { translateY: y.value }, { scale: scale.value }],
  }));

  return (
    <GestureDetector gesture={Gesture.Race(pan, tap)}>
      <Animated.View
        accessible accessibilityRole="button" accessibilityLabel={`Block ${label}`}
        style={[s.block, selected && s.selected, style]}>
        <Text style={s.text}>{label}</Text>
      </Animated.View>
    </GestureDetector>
  );
}
const s = StyleSheet.create({
  block: { width: 84, height: 84, borderRadius: theme.radius, backgroundColor: theme.block, alignItems: 'center', justifyContent: 'center' },
  selected: { borderWidth: 3, borderColor: theme.accent },
  text: { color: theme.blockText, fontSize: 34 },
});
