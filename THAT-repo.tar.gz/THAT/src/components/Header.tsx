import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme } from '../theme';

export function Header({ progress, days }: { progress: number; days: number }) {
  return (
    <View style={s.wrap} accessible accessibilityLabel={`Days learned: ${days}`}>
      <View style={s.track}><View style={[s.fill, { width: `${Math.round(progress * 100)}%` }]} /></View>
      <Text style={s.days}>Days learned: {days}</Text>
    </View>
  );
}
const s = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingHorizontal: 24, paddingTop: 12 },
  track: { flex: 1, height: 10, borderRadius: 5, backgroundColor: theme.track, overflow: 'hidden' },
  fill: { height: 10, backgroundColor: theme.accent, borderRadius: 5 },
  days: { color: theme.ink, fontSize: 16, fontWeight: '600' },
});
