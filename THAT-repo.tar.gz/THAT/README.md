# THAT

A learning app for teens with ADHD. Drag-and-drop micro-tasks, no setup screens, no streaks.

## Principles
- Zero setup: first screen is a task; anonymous user id.
- Tactile: physics-based drag with haptics. Tap-block-then-tap-zone fallback (WCAG 2.2 SC 2.5.7).
- Forgiving: "Days learned" only goes up. Wrong answers spring back, nothing is lost.
- Instant save: every interaction is saved locally, then synced to the PHP/MySQL API with idempotency keys.
- Gestalt: Proximity (prompt, zone and blocks clustered), Closure (dashed, transparent drop zone).

## Run the app
    npm install
    npx expo start
Set the API url in `src/storage.ts`.

## Run the backend
    mysql < backend/schema.sql
    cp backend/config.example.php backend/config.php   # edit credentials
    php -S 0.0.0.0:8000 -t backend   # then route /api/v1/events to backend/api/events.php

## Roadmap
Calm mode toggle, milestone celebrations (1, 3, 7, 14, 30 days), more task types, usability test with 5 to 8 teens.
