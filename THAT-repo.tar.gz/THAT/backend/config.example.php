<?php
// Copy to config.php (git-ignored) and fill in.
return ['dsn' => 'mysql:host=127.0.0.1;dbname=that;charset=utf8mb4', 'user' => 'that', 'pass' => 'change-me'];
