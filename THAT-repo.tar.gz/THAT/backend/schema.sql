CREATE TABLE users (
  id CHAR(36) PRIMARY KEY,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE task_state (
  user_id CHAR(36), task_id VARCHAR(64),
  state JSON NOT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, task_id)
);
CREATE TABLE learning_days (
  user_id CHAR(36), day DATE,
  PRIMARY KEY (user_id, day)
);
CREATE TABLE events (
  idempotency_key CHAR(36) PRIMARY KEY,
  user_id CHAR(36), type VARCHAR(32), payload JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
