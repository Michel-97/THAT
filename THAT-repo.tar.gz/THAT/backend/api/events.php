<?php
// POST /api/v1/events : idempotent, saves state on every micro-interaction.
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$cfg = require __DIR__ . '/../config.php';
$in = json_decode(file_get_contents('php://input'), true);
$uuid = '/^[0-9a-f-]{36}$/i';
foreach (['key', 'user_id'] as $f) {
  if (!isset($in[$f]) || !preg_match($uuid, $in[$f])) { http_response_code(422); echo json_encode(['error' => "bad $f"]); exit; }
}
if (!isset($in['task_id'], $in['type'], $in['local_date']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $in['local_date'])) {
  http_response_code(422); echo json_encode(['error' => 'bad request']); exit;
}

$pdo = new PDO($cfg['dsn'], $cfg['user'], $cfg['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pdo->beginTransaction();
$pdo->prepare("INSERT IGNORE INTO users (id) VALUES (?)")->execute([$in['user_id']]);
$ins = $pdo->prepare("INSERT IGNORE INTO events (idempotency_key,user_id,type,payload) VALUES (?,?,?,?)");
$ins->execute([$in['key'], $in['user_id'], $in['type'], json_encode($in['payload'] ?? new stdClass)]);

if ($ins->rowCount() === 1) { // not a retry
  $pdo->prepare("INSERT INTO task_state (user_id,task_id,state) VALUES (?,?,?)
                 ON DUPLICATE KEY UPDATE state = VALUES(state)")
      ->execute([$in['user_id'], $in['task_id'], json_encode($in['state'] ?? new stdClass)]);
  if ($in['type'] === 'task_complete') {
    $pdo->prepare("INSERT IGNORE INTO learning_days (user_id,day) VALUES (?,?)")->execute([$in['user_id'], $in['local_date']]);
  }
}
$pdo->commit();
echo json_encode(['ok' => true]);
